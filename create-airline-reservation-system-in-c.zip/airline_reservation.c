#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FLIGHTS 100
#define MAX_SEATS 200

typedef struct {
    int flightNumber;
    char destination[50];
    int totalSeats;
    int availableSeats;
    float ticketPrice;
} Flight;

Flight flights[MAX_FLIGHTS];
int flightCount = 0;

void displayMenu() {
    printf("\n------------------------------------\n");
    printf("  Airline Reservation System\n");
    printf("------------------------------------\n");
    printf("1. View Available Flights\n");
    printf("2. Book a Flight\n");
    printf("3. Cancel a Flight\n");
    printf("4. View Bookings\n");
    printf("5. Exit\n");
    printf("------------------------------------\n");
    printf("Enter your choice: ");
}

void initializeFlights() {
    // Sample data
    flights[0] = (Flight){101, "New York", 100, 50, 200.0};
    flights[1] = (Flight){102, "Los Angeles", 100, 30, 150.0};
    flights[2] = (Flight){103, "Chicago", 100, 70, 180.0};
    flightCount = 3;
}

void viewAvailableFlights() {
    printf("\nAvailable Flights:\n");
    printf("Flight Number | Destination    | Available Seats | Ticket Price\n");
    printf("--------------------------------------------------------------\n");
    for (int i = 0; i < flightCount; i++) {
        printf("%-14d | %-15s | %-15d | $%.2f\n",
               flights[i].flightNumber,
               flights[i].destination,
               flights[i].availableSeats,
               flights[i].ticketPrice);
    }
}

void bookFlight() {
    int flightNumber;
    printf("Enter flight number to book: ");
    scanf("%d", &flightNumber);

    for (int i = 0; i < flightCount; i++) {
        if (flights[i].flightNumber == flightNumber) {
            if (flights[i].availableSeats > 0) {
                flights[i].availableSeats--;
                printf("Booking successful! Flight Number %d\n", flightNumber);
                return;
            } else {
                printf("Sorry, no available seats on Flight Number %d.\n", flightNumber);
                return;
            }
        }
    }
    printf("Flight Number %d not found.\n", flightNumber);
}

void cancelFlight() {
    int flightNumber;
    printf("Enter flight number to cancel: ");
    scanf("%d", &flightNumber);

    for (int i = 0; i < flightCount; i++) {
        if (flights[i].flightNumber == flightNumber) {
            if (flights[i].totalSeats > flights[i].availableSeats) {
                flights[i].availableSeats++;
                printf("Cancellation successful! Flight Number %d\n", flightNumber);
                return;
            } else {
                printf("No bookings found for Flight Number %d.\n", flightNumber);
                return;
            }
        }
    }
    printf("Flight Number %d not found.\n", flightNumber);
}

void viewBookings() {
    printf("\nCurrent Bookings:\n");
    printf("Flight Number | Destination    | Booked Seats | Available Seats\n");
    printf("--------------------------------------------------------------\n");
    for (int i = 0; i < flightCount; i++) {
        int bookedSeats = flights[i].totalSeats - flights[i].availableSeats;
        printf("%-14d | %-15s | %-12d | %-15d\n",
               flights[i].flightNumber,
               flights[i].destination,
               bookedSeats,
               flights[i].availableSeats);
    }
}

int main() {
    int choice;
    initializeFlights();

    do {
        displayMenu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                viewAvailableFlights();
                break;
            case 2:
                bookFlight();
                break;
            case 3:
                cancelFlight();
                break;
            case 4:
                viewBookings();
                break;
            case 5:
                printf("Exiting the system.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 5);

    return 0;
}
